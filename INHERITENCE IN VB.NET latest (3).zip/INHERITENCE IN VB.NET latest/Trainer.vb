﻿Public Class Trainer
    Implements IPerson

    Property TSubject As String

    Property Experience As Double

    Public Property Name As String Implements IPerson.Name
        Get
            Throw New NotImplementedException()
        End Get
        Set(value As String)
            Throw New NotImplementedException()
        End Set
    End Property

    Public Property PhonNomber As String Implements IPerson.PhonNomber
        Get
            Throw New NotImplementedException()
        End Get
        Set(value As String)
            Throw New NotImplementedException()
        End Set
    End Property


    Private Function IPerson_DisplayData() As Object Implements IPerson.DisplayData
        Console.WriteLine("Detail of Trainer: " & Name & " " & PhonNomber & " " & TSubject & " " & Experience)
        Return Nothing
    End Function

End Class
