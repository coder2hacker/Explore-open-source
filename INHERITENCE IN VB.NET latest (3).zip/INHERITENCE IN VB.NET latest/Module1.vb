﻿Module Module1

    Sub Main()

        'Dim Student1 As New Students("P100")
        Dim Student1 As New Students()
        Console.Write("Enter You Name")
        Student1.Name = Console.ReadLine
        Student1.CreateDate = DateTime.Now

        Console.Write("Enter you number")
        Student1.PhonNomber = Console.ReadLine
        Student1.CreatedBy = Student1.Name
        Console.WriteLine(Student1.DisplayData())


        'Console.Write("Enter Your Favorite Subject ")
        'Student1.Subject = Console.ReadLine


        'Student1.DisplayData()

        ' Console.WriteLine("Detail of Student: " & Student1.Name & " " & Student1.PhonNomber & " " & Student1.Subject & " " & Student1.Id)



        'Dim Student2 As New Students("P200")
        'Student2 = ObjAsPerimiterFunc(Student2)
        ''Dim Student3 As New Students
        ''Student3 = Student2


        'Console.WriteLine(Student2.IPerson_DisplayData)

        'Console.ReadLine()


        'Dim TrainerName As New Trainer


        'Console.Write("Enter Your Trainer Name")
        'TrainerName.Name = Console.ReadLine

        'Console.WriteLine("Enter you Trainer's number")
        'TrainerName.Phone = Console.ReadLine

        'Console.Write("Enter Your Trainer Subject")
        'TrainerName.TSubject = Console.ReadLine

        'Console.Write("Enter Your Trainer Experience")
        'TrainerName.Experience = Console.ReadLine

        'TrainerName.DisplayData()


        'Dim LabPerson As New LabAsses


        'Console.Write("Enter Your LabAsses Name ")
        'LabPerson.Name = Console.ReadLine()

        'Console.WriteLine("Enter you LabAsses number ")
        'LabPerson.Phone = Console.ReadLine()

        'Console.Write("Enter Your LabAsses Subject ")
        'LabPerson.TSubject = Console.ReadLine()

        'Console.Write("Enter Your  LabAssessExperience ")
        'LabPerson.Experience = Console.ReadLine()

        'Console.Write("Enter Your Profeciency of LabPerson (1-5) ")
        'LabPerson.ProfeciencyLevel = Convert.ToInt64(Console.ReadLine())

        'LabPerson.DisplayData()

        Console.WriteLine("Enter Any Key to exit")
        Console.ReadKey()

    End Sub


    'Public Function ObjAsPerimiterFunc(objj As Students) As Students

    '    Console.WriteLine("Enter You Name")
    '    objj.Name = Console.ReadLine

    '    Console.WriteLine("Enter you number")
    '    objj.PhonNomber = Console.ReadLine

    '    'Console.WriteLine("Enter Your Favorite Subject ")
    '    'objj.Subject = Console.ReadLine

    '    Return objj
    'End Function

End Module


