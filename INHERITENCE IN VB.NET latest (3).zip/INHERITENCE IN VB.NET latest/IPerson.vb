﻿Public Interface IPerson

    Property Name As String
    Property PhonNomber As String

    Function DisplayData()


End Interface



