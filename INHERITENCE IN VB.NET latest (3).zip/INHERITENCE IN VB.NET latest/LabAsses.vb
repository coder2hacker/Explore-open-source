﻿Public Class LabAsses
    Inherits Trainer

    Property ProfeciencyLevel As Integer

    Public Function DisplayData()
        Console.WriteLine("Detail of LabAssistent: " & Name & " " & PhonNomber & " " & TSubject & " " & Experience & " " & ProfeciencyLevel)
        Return Nothing
    End Function


End Class
