﻿
Public Class Students
    Implements IPerson, ITrack



    'Implements ITrack

    Property Name As String Implements IPerson.Name
    Property PhonNomber As String Implements IPerson.PhonNomber

    Property CreateDate As DateTime Implements ITrack.CreatedDate
    Property CreatedBy As String Implements ITrack.CreatedBy

    Public Function DisplayData() As Object Implements IPerson.DisplayData

        Console.WriteLine("Detail of Student: " & Environment.NewLine & Name & " " & Environment.NewLine & PhonNomber & " " & "Created By :" & CreatedBy & Environment.NewLine & CreateDate)


        'Console.WriteLine("Detail of Student: " & Environment.NewLine & Name & " " & Environment.NewLine & PhonNomber & " " & Environment.NewLine & Subject & " " & Environment.NewLine & Id & CreatedBy & Environment.NewLine & CreateDate)

        Return Nothing
    End Function









    'Public Sub New()
    '    Console.WriteLine("Child constructor")
    'End Sub

    'Private _id As String
    'Public Property Id() As String
    '    Get
    '        Return _id
    '    End Get
    '    Set(ByVal value As String)
    '        _id = value
    '    End Set
    'End Property
    'Public Sub New(ByVal ID As String)
    '    _id = ID
    'End Sub
    'Public _Subject As String

    'Public Property Subject() As String
    '    Get
    '        Return _Subject
    '    End Get
    '    Set(ByVal value As String)
    '        _Subject = value
    '    End Set
    'End Property



    'Public Property PhonNomber As String Implements IPerson.PhonNomber
    '    Get
    '        Throw New NotImplementedException()
    '    End Get
    '    Set(value As String)
    '        Throw New NotImplementedException()
    '    End Set
    'End Property




    'Private DateToday As DateTime    'kuraphat
    'Public Property YourDate() As String
    '    Get
    '        Return DateTime.Now

    '    End Get
    '    Set(ByVal value As String)
    '        DateToday = value
    '    End Set
    'End Property






    'Public Function DisplayData()
    '    Console.WriteLine("Detail of Student: " & Environment.NewLine & Name & " " & Environment.NewLine & Phone & " " & Environment.NewLine & Subject & " " & Environment.NewLine & Id)
    '    Return Nothing
    'End Function



End Class
