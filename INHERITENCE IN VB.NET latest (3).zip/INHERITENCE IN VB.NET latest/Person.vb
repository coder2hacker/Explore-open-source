﻿'Public Class Person
'    Public Sub New()
'        Console.WriteLine("Parent constructor")
'    End Sub

'    'Name is a Private data Member of PARENT Class
'    Dim _Name As String
'    Dim _Phone As String

'    Public Property Name() As String
'        Get
'            Return _Name
'        End Get
'        Set(ByVal value As String)
'            _Name = value
'        End Set
'    End Property

'    Public Property Phone() As String
'        Get
'            Return _Phone
'        End Get
'        Set(ByVal value As String)
'            _Phone = value
'        End Set
'    End Property

'    Public Overridable Function DisplayData()
'        Console.WriteLine("Detail of  Person: " & Name & " " & Phone)
'        Return Nothing
'    End Function





'End Class
