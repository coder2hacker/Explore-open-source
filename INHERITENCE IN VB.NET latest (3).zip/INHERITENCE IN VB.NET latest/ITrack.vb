﻿Public Interface ITrack

    Property CreatedBy As String
    Property CreatedDate As DateTime

End Interface
