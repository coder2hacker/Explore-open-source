﻿Imports System.Data.SqlClient
Imports System.Reflection

Public Class DataBaseConnect
    Dim ContStr As String = "Data Source=DEL1-LHP-N65356\SQLEXPRESS;Initial Catalog=Practice;Integrated Security=True"

    Dim Conn As SqlConnection = New SqlConnection(ContStr)

    Public Function getConnect() As SqlConnection
        Conn.Open()
        Return Conn
    End Function
    Public Sub disConnect()
        Conn.Close()
    End Sub
    Public Function SqlComd(Query As String, kvp As CLKeyValuePair) As String
        Dim SqlCmd As SqlCommand = New SqlCommand(Query, getConnect())

        For Each item In kvp
            SqlCmd.Parameters.AddWithValue(item.key, item.value)
        Next
        Dim status As String = SqlCmd.ExecuteNonQuery
        disConnect()
        Return status
    End Function
    Public Function FillDataset(Query As String) As DataSet
        Dim dataSet As DataSet = New DataSet()
        Dim adapter As SqlDataAdapter = New SqlDataAdapter(Query, Conn)
        getConnect()
        adapter.Fill(dataSet)
        disConnect()
        Return dataSet
    End Function

    Private Shared Function GetItem(Of T)(ByVal dr As DataRow) As T
        Dim temp As Type = GetType(T)
        Dim obj As T = Activator.CreateInstance(Of T)()

        For Each column As DataColumn In dr.Table.Columns

            For Each pro As PropertyInfo In temp.GetProperties()

                If pro.Name = column.ColumnName Then
                    Dim colType As Type = dr(column.ColumnName).[GetType]()

                    If colType = GetType(System.DBNull) Then
                        pro.SetValue(obj, Nothing, Nothing)
                    Else

                        If column.DataType.ToString() = "System.UInt64" Then
                            pro.SetValue(obj, Convert.ToBoolean(dr(column.ColumnName)), Nothing)
                        Else
                            pro.SetValue(obj, dr(column.ColumnName), Nothing)
                        End If
                    End If
                Else
                    Continue For
                End If
            Next
        Next

        Return obj
    End Function

    Public Shared Function ToList(Of T)(ByVal dt As DataTable) As List(Of T)
        Dim data As List(Of T) = New List(Of T)()
        If dt Is Nothing Then Return data

        For Each row As DataRow In dt.Rows
            Dim item As T = GetItem(Of T)(row)
            data.Add(item)
        Next

        Return data
    End Function
End Class

Public Class KeyValuePair
    Property key As String
    Property value As String
    Public Sub New(key As String, Value As String)
        Me.key = key
        Me.value = Value
    End Sub

End Class

Public Class CLKeyValuePair
    Inherits List(Of KeyValuePair)

End Class
