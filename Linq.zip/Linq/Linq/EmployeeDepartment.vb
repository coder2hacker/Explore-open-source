﻿Public Class EmployeeDepartment
    Property deptId As Integer
    Property depName As String

    Dim dbConnect As New DataBaseConnect
    Public Sub New()

    End Sub
    Public Sub New(deptId As Integer, depName As String)
        Me.deptId = deptId
        Me.depName = depName
    End Sub

    Public Function StInsertData(Name As String, Email As String, City As String) As String
        Dim selectCmd As String = "INSERT INTO [dbo].[Department]
           ([DepartmentName])
     VALUES
           (@DepartmentName)"
        'Dim selectCmd As String = "Sp_InsertData"
        Dim keyValue As New CLKeyValuePair
        keyValue.Add(New KeyValuePair("@DepartmentName", depName))

        Dim InsertStat As Integer = dbConnect.SqlComd(selectCmd, keyValue)
        Dim InsertionStatus As String = ""
        If InsertStat = 1 Then
            InsertionStatus = "Data Saved Successfully"

        Else
            InsertionStatus = "OOPS!!! Something Went Wrong...."
        End If
        Return InsertionStatus
    End Function

    Public Function ReturnDepartment() As DataSet
        Dim selectQuery As String = "SELECT [DepID]
         ,[DepartmentName]
         FROM [dbo].[Department]"
        'Dim d As DataSet =
        Return dbConnect.FillDataset(selectQuery)

    End Function
    'Public Overrides Function DisplayData()
    '    Console.WriteLine("Details of Employee 3 : " & empID() & " " & Name() & " " & Email & " " & EmpSalary() & " " & City & " " & deptId & " " & depName)
    '    Return Nothing
    'End Function
End Class
