﻿Module Module1

    Sub Main()
        Dim dep As New EmployeeDepartment
        Dim DepList As New List(Of EmployeeDepartment)
        Dim dt0 As DataTable = dep.ReturnDepartment().Tables(0)
        DepList = (From d In dt0.Rows Select New EmployeeDepartment() With {
                               .depName = d("DepartmentName").ToString
        }).ToList()


        Dim emp As New Employee
        Dim EmpList As New List(Of Employee)
        Dim dt As DataTable = emp.ReturnEmployees().Tables(0)
        EmpList = (From ep In dt.Rows Select New Employee() With {
                                         .Name = ep("employee_Name").ToString(),
                                          .Email = ep("Employee_Email").ToString(),
                                          .City = ep("Emp_city").ToString(),
                                          .depId = Integer.Parse(ep("Dep_id"))}).ToList()

        'CombList = From e In EmpList Join d In DepList On e.depId Equals d.deptId Select e.Name, d.depName

        Dim list = (From e In EmpList Join d In DepList On e.depId Equals d.deptId Select New With {Key .Name = e.Name, Key .depName = d.depName})

        For Each item In list
            Console.WriteLine("Details of Employee " + Environment.NewLine + "Employee Name : {0} , Department Name : {1}", item.Name, item.depName)
            Console.WriteLine()

        Next


        Console.ReadKey()


    End Sub

End Module
#Region "Basic way of adding in list"
'DepList.Add(New EmployeeDepartment(deptId:=1, depName:="HR"))
'DepList.Add(New EmployeeDepartment(deptId:=2, depName:="Marketing"))
'DepList.Add(New EmployeeDepartment(deptId:=3, depName:="Sales"))
'DepList.Add(New EmployeeDepartment(deptId:=4, depName:="IT"))
'EmpList.Add(New Employee(empID:=101, Name:="Nikita Jain", Email:="Nikita@gmail.com", City:="Noida", depId:=1))
'EmpList.Add(New Employee(empID:=102, Name:="John", Email:="John@gmail.com", City:="Delhi", depId:=1))
'EmpList.Add(New Employee(empID:=103, Name:="Alex", Email:="Alex@gmail.com", City:="Noida", depId:=2))
'EmpList.Add(New Employee(empID:=104, Name:="Rachel", Email:="Rachel@gmail.com", City:="Delhi", depId:=3))
'EmpList.Add(New Employee(empID:=105, Name:="Peter", Email:="Peter@gmail.com", City:="Noida", depId:=2))
'EmpList.Add(New Employee(empID:=106, Name:="Jeff", Email:="Jeff@gmail.com", City:="Delhi", depId:=4))
'EmpList.Add(New Employee(empID:=107, Name:="Pheobe", Email:="Pheobe@gmail.com", City:="Delhi", depId:=1))
'EmpList.Add(New Employee(empID:=108, Name:="Noah", Email:="Noah@gmail.com", City:="Noida", depId:=4))
'EmpList.Add(New Employee(empID:=109, Name:="Micheal", Email:="Micheal@gmail.com", City:="Noida", depId:=3))
'EmpList.Add(New Employee(empID:=110, Name:="Akansha", Email:="Akansha@gmail.com", City:="Delhi", depId:=1))
'EmpList.Add(New Employee(empID:=111, Name:="Arya", Email:="Arya@gmail.com", City:="Noida", depId:=2))


 'Dim words As String() = {"hello", "wonderful", "LINQ", "beautiful", "world"}

        '' Get only short words
        'Dim shortWords = From word In words Where word.Length <= 5 Select word

        '' Print each word out.
        'For Each word In shortWords
        '    Console.WriteLine(word)
        'Next
        'Console.ReadLine()

#End Region
