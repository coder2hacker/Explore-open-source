﻿Public Class Employee
    Property empID As Integer
    Property Name As String
    Property Email As String
    Property City As String
    Property depId As Integer

    Dim dbConnect As New DataBaseConnect
    Public Sub New()

    End Sub
    Public Sub New(empID As Integer, Name As String, Email As String, City As String, depId As Integer)
        Me.empID = empID
        Me.Name = Name
        Me.Email = Email
        Me.City = City
        Me.depId = depId
    End Sub

    Public Function StInsertData(Name As String, Email As String, City As String) As String
        Dim selectCmd As String = "INSERT INTO [dbo].[Employee]
              ([Employee_Name]
              ,[Employee_Email]
              ,[Emp_city],
           [Dep_id])
        VALUES
              (@Employee_Name, 
              @Employee_Email, 
              @Emp_city, @Dep_id)"
        'Dim selectCmd As String = "Sp_InsertData"
        Dim keyValue As New CLKeyValuePair
        keyValue.Add(New KeyValuePair("@Employee_Name", Name))
        keyValue.Add(New KeyValuePair("@Employee_Email", Email))
        keyValue.Add(New KeyValuePair("@Emp_city", City))
        keyValue.Add(New KeyValuePair("@Dep_id", depId))

        Dim InsertStat As Integer = dbConnect.SqlComd(selectCmd, keyValue)
        Dim InsertionStatus As String = ""
        If InsertStat = 1 Then
            InsertionStatus = "Data Saved Successfully"

        Else
            InsertionStatus = "OOPS!!! Something Went Wrong...."
        End If
        Return InsertionStatus
    End Function

    Public Function ReturnEmployees() As DataSet
        Dim selectQuery As String = "SELECT [Employee_Id]
      ,[Employee_Name]
      ,[Employee_Email]
      ,[Emp_city]
      ,[Dep_id]
  FROM [dbo].[Employee]"
        'Dim d As DataSet =
        Return dbConnect.FillDataset(selectQuery)

    End Function
    Public Function ConvertList()

    End Function


    'Public Overridable Function DisplayData()
    '    Console.WriteLine("Details of Employee 3 : " & empID() & " " & Name() & " " & Email & " " & EmpSalary() & " " & City)
    '    Return Nothing
    'End Function
End Class
