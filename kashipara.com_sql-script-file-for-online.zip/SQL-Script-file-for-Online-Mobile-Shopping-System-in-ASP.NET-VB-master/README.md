# Script-File-for-Online-Mobile-Shopping-System-in-ASP.NET
this file contains Table Script Files which is necessary for developing Online Mobile Shopping System in ASP.NET VB 
